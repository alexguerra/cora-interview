package corabank;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class Main {

    @Autowired
    Conta_acesso repositorio;

    @GetMapping("/health")
    String health() {
        return "Live!";
    }

    @PostMapping("/{id}")
    Account get(@PathVariable("id") int id) {
        return repositorio.findById(id).get();
    }

    @GetMapping("/corabank")
    String salvar(@RequestBody Account account) {

        account.name = "Conta Cora";
        account.active = true;

        if (account.active) {

            if (account.balance > 0) {

                // Implrimindo saldo
                System.out.println("- Balance: " + account.balance);

                // Depositando 10
                account.balance = account.balance + 10;

                // Salvando conta
                repositorio.save(account);


                // Implrimindo saldo
                System.out.println("- Balance: " + account.balance);


            } else {
                System.out.println("Não tem saldo inicial");
            }
        } else {
            System.out.println("Conta não está ativa");
        }
        return "Teste";
    }

    String atualizar() {
        Account account = new Account();
        account.name = "Conta Cora";
        account.active = true;

        // Atualizando conta
        repositorio.save(account);

        if (account.balance > 0) {

            // Sacando 5
            account.balance = account.balance - 5;

            // Atualizando conta
            repositorio.save(account);

            // Implrimindo saldo
            System.out.println("- Balance: " + account.balance);

        } else {
            System.out.println("Não foi possível atualizar!");
        }
        return "Teste Atualizar";
    }

}
