package corabank;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Account {

    @Id
    Integer id;
    String name;
    Double balance;
    boolean active;

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Double getBalance() {
        return balance;
    }

    public boolean isActive() {
        return active;
    }

    public Account setId(Integer id) {
        this.id = id;
        return this;
    }

    public Account setName(String name) {
        this.name = name;
        return this;
    }

    public Account setBalance(Double balance) {
        this.balance = balance;
        return this;
    }

    public Account setActive(boolean active) {
        this.active = active;
        return this;
    }
}
