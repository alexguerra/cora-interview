package br.com.corabank;

import corabank.Account;
import corabank.CorabankApplication;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = {CorabankApplication.class}, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class IntegrationTest {

    @LocalServerPort
    private int port;

    private TestRestTemplate restTemplate = new TestRestTemplate();

    @Test
    public void startContext() {
    }

    @Test
    public void deveSalvarUmaContaNova() {
        Integer id = 1;

        // Salva uma nova conta
        String postUrl = "http://localhost:" + port + "/corabank";
        Account postParameter = new Account();
        postParameter.setId(id);
        postParameter.setName("Teste");
        postParameter.setActive(true);
        postParameter.setBalance(10d);
        ResponseEntity<String> response = restTemplate.postForEntity(postUrl, postParameter, String.class);
        assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));

        // Recupera a conta
        String getUrl = "http://localhost:" + port + "/" + id;
        Account saved = restTemplate.postForEntity(getUrl, null, Account.class).getBody();
        assertEquals(10d, saved.getBalance(), 0.5d);
        assertEquals("Teste", saved.getName());
        assertTrue(saved.isActive());
    }
}